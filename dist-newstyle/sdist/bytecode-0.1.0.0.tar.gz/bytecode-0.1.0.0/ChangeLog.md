# Changelog for bytecode

## Unreleased changes
