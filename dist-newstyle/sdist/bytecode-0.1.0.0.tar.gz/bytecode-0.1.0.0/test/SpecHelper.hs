module SpecHelper
    ( module Test.Hspec
    , module Bytecode
    ) where

import Test.Hspec
import Bytecode